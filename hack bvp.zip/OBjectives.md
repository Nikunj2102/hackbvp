# Objectives

- Home
  - Picture/Pattern
  - Register button
- About
  - HackBvp
- Prize
- Rules
- Judges
- Venue
- Footer

---

